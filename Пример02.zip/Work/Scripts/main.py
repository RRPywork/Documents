"""
Скрипт для создания главного окна приложения
Формальные переменные:
Возвращает: -
Автор: Ракина А.С. БИВ174
"""

import sys
sys.path.append('../Library/')

from tkinter import Tk, Frame, Toplevel, Label, Entry, Button, Checkbutton, Scale, Canvas, Scrollbar, FLAT, GROOVE, N, S, E, W, IntVar, END, YES, BOTH, SOLID, LabelFrame

from tkinter.messagebox import showerror, showinfo
from params import path_to_lib, path_to_report, color_1, color_2, color_3, color_4, color_5, color_6, color_7, color_8, color_9, color_10, font_1, font_2, font_3, font_4, font_5, main_window_size, frame_top_size, frame_right_size, myFrame_size, frame_size, button_size, record_label_size, but_edit_win_size

from library import import_lib, fetch_record

import pickle

m = 0
states = {}
fieldnames = (('title', 'Название'), ('author', 'Автор'),
              ('genre', 'Раздел'), ('pages', 'Число страниц'),
              ('price', 'Цена'),
              ('year', 'Год издания'))
global base

def show_base(lib):
    """
    Функция для вывода содержимого базы на экран
    Формальные переменные: string - строка, помещаемая на экран, n - номер строки
    Возвращает: -
    Автор: Ракина А.С. БИВ174
    """
    for widget in frame.winfo_children():
        widget.destroy()
    frame.grid_forget()
    n = 0
    Label(frame, text="Haзвание").grid(row=n, column=0, pady=5)
    Label(frame, text="Автор").grid(row=n, column=1, pady=5)
    Label(frame, text="Раздел").grid(row=n, column=2, pady=5)
    Label(frame, text="Страницы").grid(row=n, column=3, pady=5)
    Label(frame, text="Цена").grid(row=n, column=4, pady=5)
    Label(frame, text="Год издания").grid(row=n, column=5, pady=5)
    for key in lib:
        n = n + 1
        m = -1
        for key2 in lib[key]:
            m += 1
            string = str(lib[key][key2])
            l = Label(frame, text=string,fg=color_7, font=font_1, bd=0.5, highlightbackground=color_7, relief=GROOVE)
            l.grid(row = n,column=m, sticky=W+E, pady=5)

def export_lib(lib):
    """
    Функция для записи базы в файл
    Формальные переменные: export_filename - имя загружаемого файла, libfile - указатель на файл
    Возвращает: -
    Автор: Ракина А.С. БИВ174
    """
    try:
        libfile = open(path_to_lib, 'wb')
        pickle.dump(lib, libfile)
        libfile.close()
    except:
        showerror(title='Ошибка!', message="Ошибка сохранения!")
    else:
        showinfo("Done!", "База данных сохранена!")
    import_lib(path_to_lib) #обновление базы

def edit_lib():
    """
    Функция для создания окошка редактирования базы
    Формальные переменные: win_edit - указатель на окно; entries - словарь входных значений
    Возвращает: -
    Автор: Поздняков Филипп БИВ174
    """
    win_edit = Toplevel(root, bg = color_3)
    win_edit.title("Редактирование")

    global entries
    entries = {}
    n = 0
    for (ix, label) in enumerate((('key', 'Ключ'),) + fieldnames):
        n += 1
        lab = Label(win_edit, text=label[1], bg = color_3,fg = color_7,)
        ent = Entry(win_edit)
        lab.grid(row=ix, column=0, sticky=W+E,padx = 10, pady = 3)
        ent.grid(row=ix, column=1, columnspan = 2,sticky=W+E,padx=10, pady=3)
        entries[label[1]] = ent

    fetch_but = Button(win_edit,but_edit_win_size,text="Показать",
                       font=font_2,fg=color_7)
    fetch_but.grid(row=n+1, column=0, padx=10, pady=0)
    fetch_but.bind('<Button-1>', lambda event: fetch_record(base, fieldnames,
                                                            entries))
    Button(win_edit, but_edit_win_size, text="Обновить",font = font_2,fg = color_7,
           command=update_record).grid(row=n+1, column=1, padx = 10, pady = 10)
    Button(win_edit, but_edit_win_size, text="Удалить",font = font_2,fg = color_7,
           command=delete_record).grid(row=n+1, column=2, padx = 10, pady = 10)

    win_edit.resizable(width = False, height = False)
    win_edit.grab_set()

def update_record():
    """
    Функция для обновления информации по книге или создания новой записи
    Формальные переменные: key – ключ, record – словарь с информацией по книге,
    flag – логическая переменная для отслеживания ошибки редактирования
    Возвращает: ничего не возвращает, в случае успеха запись запись по существующей книге обновляется или создается новая запись
    Автор: Поздняков Филипп БИВ174
    """
    key = entries['Ключ'].get()
    if key in base:
        record = base[key]
    elif key == '':
        showerror(title='Ошибка!', message='Введите ключ!')
        return
    else:
        record = {}
    flag = True
    for field in fieldnames:
        scan_var = entries[field[1]].get()
        if field[0] == 'genre':
            if (scan_var != 'Зарубежная литература' and
               scan_var != 'Русская литература' and
               scan_var != 'Античная литература'):
                showerror(title='Ошибка!', message='Неверно введенный раздел')
                flag = False
                break
            else:
                record[field[0]] = scan_var
        elif field[0] == 'pages' or field[0] == 'price' or field[0] == 'year':
            try:
                scan_var = int(scan_var)
            except:
                showerror(title='Ошибка!', message="Неверный формат данных для поля \'" + field[1] + "\'")
                flag = False
                break
            else:
                if field[0] == 'pages' and (scan_var < 50 or scan_var > 1000):
                    showerror(title='Ошибка!', message='Неверное число для поля \'' + field[1] + '\'')
                    flag = False
                    break
                elif field[0] == 'price' and (scan_var < 50 or scan_var > 1000):
                    showerror(title='Ошибка!', message='Неверное число для поля \'' + field[1] + '\'')
                    flag = False
                    break
                elif field[0] == 'year' and (scan_var < 1990 or scan_var > 2018):
                    showerror(title='Ошибка!', message='Неверное число для поля \'' + field[1] + '\'')
                    flag = False
                    break
                else:
                    record[field[0]] = scan_var
        else:
            record[field[0]] = scan_var
    if flag:
        base[key] = record
        show_base(base) #обновление базы
        showinfo("Edited!", "Запись обновлена!")

def delete_record():
    """
    Функция для удаления выбранной записи
    Формальные переменные: key – ключ
    Возвращает: -
    Автор: Ракина А.С. БИВ174
    """
    key = entries['Ключ'].get()
    if key in base:
        base.pop(key)
        show_base(base) #обновление базы
        for field in fieldnames:
            entries[field[1]].delete(0, END)
        showinfo("Deleted!", "Запись удалена!")
    else:
        showerror(title='Ошибка!', message='Введен неверный ключ!')

def filter_name(item, label_text):
    """
    Функция для создания виджетов класса Checkbutton для сортировки по ключу строкового типа
    Формальные переменные: lab_name - переменная для надписи, che - переменная для флажка
    Возвращает: unique_keys - множество уникальных ключей
    Автор: Ракина А.С. БИВ174
    """
    global m
    m += 1
    lab_name = Label(frame_canvas_right, font=font_2, fg=color_6, bg=color_1,
                     text=label_text, anchor="w", width=20)
    lab_name.grid(row = m, padx = 15, pady = 5)

    unique_keys = set()
    states_name = []
    for key in base.values():
        unique_keys.add(key[item])

    for key in unique_keys:
        m += 1
        var = IntVar()
        che = Checkbutton(frame_canvas_right, text=key, bg=color_1,font=font_1,
                          fg = color_4,variable=var, activebackground=color_5,
                          selectcolor='blue')
        che.select()
        states_name.append(var)
        che.grid(row = m, sticky=W, padx = 15, pady = 3)
    states[item] = states_name
    return list(unique_keys)

def filter_num(item, label_text, low_lim, up_lim, step):
    """
    Функция для создания виджетов класса Scale для отбора записей по значениям числовых полей, не превышающих заданных
    Формальные переменные: slider – экземпляр класса Scale, lab_name – экземпляр класса Label, m – перемення для нумерации рядов в grid_forget
    Возвращает: unique_keys – множество уникальных ключей
    Автор: Поздняков Филипп БИВ174
    """
    global m
    m += 1
    lab_name = Label(frame_canvas_right, font=font_2, fg=color_6, bg=color_1,
                     text=label_text, anchor="w", width=20)
    lab_name.grid(row = m, padx = 15, pady = (15, 0))

    unique_keys = set()
    for key in base.values():
        unique_keys.add(key[item])

    m += 1
    var = IntVar()
    slider = Scale(frame_canvas_right, bg=color_1, font=font_1, fg=color_4,
                   variable=var, from_=low_lim, to=up_lim, length=200,
                   orient='horizontal',
                   sliderlength = 12,#ширина ползунка
                   troughcolor = color_4,
                   tickinterval = 150,
                   resolution = step,
                   sliderrelief = GROOVE,
                   width = 15,
                   activebackground=color_5, borderwidth=0)
    slider.set(up_lim)
    slider.grid(row = m, padx = 15, pady = (0, 15))

    states[item] = var
    return list(unique_keys)

def filter(lis):
    """
    Функция для создания копии исходной базы из выбранных по критерию полей, а также для анализа выбранных записей по критериям и создания окна с выводом результата анализа
    Формальные переменные:prop_key - список ключей подходящих по критерию; fil_base, final_base - копии базы, lis - словарь с информацией по отобранным записям
    average_pages, average_price, average_year – переменные для среднего арифметического по числовым полям
    variance_pages, variance_price, variance_year – переменные для выборочной дисперсии по числовым полям
    amount – количество подходящих записей
    win_analisys – экземпляр класса Toplevel
    lab1-lab14 – экземпляры класса Label
    Возвращает: -
    Автор: Масленникова Д.А. БИВ174
    """
    fil_base = dict()
    prop_key = []
    for i in range(len(states['genre'])):
        if states['genre'][i].get():
            prop_key.append(lis['genre'][i])
    for key in base:
        for key2 in base[key]:
            if base[key][key2] in prop_key:
                fil_base[key] = base[key]
    final_base = {}
    for key in fil_base:
        if (fil_base[key]['pages'] <= states['pages'].get() and
           fil_base[key]['price'] <= states['price'].get() and
           fil_base[key]['year'] <= states['year'].get()):
            final_base[key] = fil_base[key]

    show_base(final_base)#обновляем базу в приложении

    if (not len(final_base)):
        for widget in frame.winfo_children():
            widget.destroy()
        frame.grid_forget()
        showinfo("Сообщение", "Нет записей")
    else:
        amount = len(final_base)

        average_pages = 0
        average_price = 0
        average_year = 0

        variance_pages = 0
        variance_price = 0
        variance_year = 0

        for key in final_base:
            average_pages += final_base[key]['pages']
            average_price += final_base[key]['price']
            average_year += final_base[key]['year']

        average_pages //= amount
        average_price //= amount
        average_year //= amount

        for key in final_base:
            variance_pages += (final_base[key]['pages'] - average_pages) ** 2
            variance_price += (final_base[key]['price'] - average_price) ** 2
            variance_year += (final_base[key]['year'] - average_year) ** 2

        variance_pages //= amount
        variance_price //= amount
        variance_year //= amount

        win_analysis = Toplevel(root, bg = color_3)
        win_analysis.title("Анализ результата")

        lab1 = Label(win_analysis, text='Количество записей:', bg = color_3, fg = color_7)
        lab2 = Label(win_analysis, text=str(amount), bg = color_3, width = 5, fg = color_7)
        lab1.grid(row=0, column=0, sticky=W+E,padx = 10, pady = (10,3))
        lab2.grid(row=0, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab3 = Label(win_analysis, text='Среднее по страницам:', bg = color_3, fg = color_7)
        lab4 = Label(win_analysis, text=str(average_pages), bg = color_3, width = 5, fg = color_7)
        lab3.grid(row=1, column=0, sticky=W+E,padx = 10, pady = 3)
        lab4.grid(row=1, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab5 = Label(win_analysis, text='Дисперсия по страницам:', bg = color_3, fg = color_7)
        lab6 = Label(win_analysis, text=str(variance_pages), bg = color_3, width = 5, fg = color_7)
        lab5.grid(row=2, column=0, sticky=W+E,padx = 10, pady = 3)
        lab6.grid(row=2, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab7 = Label(win_analysis, text='Среднее по ценам:', bg = color_3, fg = color_7)
        lab8 = Label(win_analysis, text=str(average_price), bg = color_3, width = 5, fg = color_7)
        lab7.grid(row=3, column=0, sticky=W+E,padx = 10, pady = 3)
        lab8.grid(row=3, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab9 = Label(win_analysis, text='Дисперсия по ценам:', bg = color_3, fg = color_7)
        lab10 = Label(win_analysis, text=str(variance_price), bg = color_3, width = 5, fg = color_7)
        lab9.grid(row=4, column=0, sticky=W+E,padx = 10, pady = 3)
        lab10.grid(row=4, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab11 = Label(win_analysis, text='Среднее по годам:', bg = color_3, fg = color_7)
        lab12 = Label(win_analysis, text=str(average_year), bg = color_3, width = 5, fg = color_7)
        lab11.grid(row=5, column=0, sticky=W+E,padx = 10, pady = 3)
        lab12.grid(row=5, column=1, sticky=W+E,padx = (0,2), pady = 3)

        lab13 = Label(win_analysis, text='Дисперсия по годам:', bg = color_3, fg = color_7)
        lab14 = Label(win_analysis, text=str(variance_year), bg = color_3, width = 5, fg = color_7)
        lab13.grid(row=6, column=0, sticky=W+E,padx = 10, pady = 3)
        lab14.grid(row=6, column=1, sticky=W+E,padx = (0,2), pady = 3)

        def analysis_export():
            """
            Функция создания окна ввода имени файла для экспорта данных анализа
            Формальные переменные: win_export_file – экземпляр класса Toplevel;
            ent – экземпляр класса Entry для ввода имени файла
            Возвращает: -
            Автор: Масленникова Д.А. БИВ174
            """
            win_export_file = Toplevel(root, bg = color_3)
            win_export_file.title('Анализ результата')

            Label(win_export_file, text='Введите имя файла для отчета:', fg = color_7,
                  bg = color_3).grid(row=0, column=0, sticky=W+E, padx=10, pady=(10,3))
            ent = Entry(win_export_file, bd=0)
            ent.grid(row=0, column=1, padx = 20, pady = 0)

            def submit():
                """
                Функция для создания файла в заданной директории с данными анализа
                Формальные переменные: file_name – имя файла; fp – указатель на файл
                Возращает: ничего не возвращает
                Автор: Масленникова Д.А. БИВ174
                """
                file_name = ent.get()
                if file_name == '':
                    file_name = 'report'
                fp = open(path_to_report+file_name+".txt", "w")
                genres = []
                for i in range(len(states['genre'])):
                    if states['genre'][i].get():
                         genres.append(lis['genre'][i])
                print("\t\tАнализ отобранных записей\t\t\n", file=fp)
                print("### Разделы: " + ', '.join(genres), file=fp)
                print("### Количество страниц <= " + str(states['pages'].get()),
                     file=fp)
                print("### Цена <= " + str(states['price'].get()),
                     file=fp)
                print("### Год издания <= " + str(states['year'].get()) + '\n',
                     file=fp)
                print("Количество записей = "+str(amount)+"\n", file=fp)
                print("Среднее по страницам = "+str(average_pages), file=fp)
                print("Дисперсия по страницам = "+str(variance_pages)+"\n", file=fp)
                print("Среднее по ценам = "+str(average_price), file=fp)
                print("Дисперсия по ценам = "+str(variance_price)+"\n", file=fp)
                print("Среднее по годам = "+str(average_year), file=fp)
                print("Дисперсия по годам = "+str(variance_year)+"\n", file=fp)
                fp.close()
                win_export_file.destroy()

            Button(win_export_file, but_edit_win_size, text='Выгрузить', font=font_2, fg = color_7,
                   command=submit).grid(row=1, columnspan = 2, padx=10, pady=10)

            win_export_file.resizable(width = False, height = False)
            win_export_file.grab_set()

        Button(win_analysis, but_edit_win_size, text="Экспорт", font = font_2, fg = color_7,
               command=analysis_export).grid(row=7, column=0, padx = (10,2), pady = 10)
        Button(win_analysis, but_edit_win_size, text="Выход", font = font_2, fg = color_7,
               command=win_analysis.destroy).grid(row=7, column=1,
                                                  padx = (2,10), pady = 10)

        win_analysis.resizable(width = False, height = False)
        win_analysis.grab_set()

root=Tk()
root.title("База данных")
root.configure(main_window_size)

frame_top = Frame(root, frame_top_size, bg=color_10)
frame_right = Frame(root, frame_right_size, bg=color_1)
frame_top.grid(column = 0, row = 0, columnspan = 2, sticky=N+S+E+W)
frame_right.grid(column = 1, row = 1, sticky=N+S+E+W)

canvas_right = Canvas(frame_right, frame_right_size, bg=color_1)
frame_canvas_right = Frame(canvas_right, frame_right_size, bg=color_1)
vertScrollbar_right=Scrollbar(frame_right,orient="vertical",
                             command=canvas_right.yview)
canvas_right.configure(yscrollcommand=vertScrollbar_right.set)
canvas_right.grid(row=0, column=0, sticky=N+S+E+W)
frame_right.grid_columnconfigure(0, weight=100)
vertScrollbar_right.grid(row=0, column=1, sticky=N+S+E)
frame_right.grid_columnconfigure(1, weight=1)
canvas_right.create_window((0,0),window=frame_canvas_right, anchor = 'nw')

lab_filter = Label(frame_canvas_right, font=font_3, fg=color_1, bg=color_6, width =20, text = "F I L T E R")
lab_filter.grid(row = 0, padx = 0, pady = 10)
frame_right.grid_rowconfigure(m, weight=1)
filter_but = Button(frame_canvas_right, button_size, text="A P P L Y", font=font_4, fg = color_1,
                    highlightbackground = color_8)
filter_but.bind("<Button-1>", (lambda event: filter(lis)))
filter_but.bind("<Enter>",(lambda event:filter_but.configure(highlightbackground = color_4, fg = color_7)))
filter_but.bind("<Leave>",(lambda event:filter_but.configure(highlightbackground = color_8, fg = color_1)))
size = (30, 30)

but_export = Button(frame_top, button_size, highlightbackground=color_3,
                    font=font_5, fg=color_1, text="S A V E", relief=FLAT)
but_export.grid(row = 0, column = 0, padx = 20, pady = 20)
but_export.bind("<Button-1>",(lambda event: export_lib(base)))#сохранение базы

but_export.bind("<Enter>",(lambda event:but_export.configure(highlightbackground = color_4, fg = color_7)))
but_export.bind("<Leave>",(lambda event:but_export.configure(highlightbackground = color_8, fg = color_1)))

but_edit = Button(frame_top, button_size, highlightbackground=color_3,
                  font=font_5, fg=color_1, text="E D I T", relief=FLAT)
but_edit.grid(row = 0, column = 1, padx = 0, pady = 20)
but_edit.bind("<Enter>",(lambda event:but_edit.configure(highlightbackground = color_4, fg = color_7)))
but_edit.bind("<Leave>",(lambda event:but_edit.configure(highlightbackground = color_8, fg = color_1)))
but_edit.bind("<Button-1>",(lambda event: edit_lib()))

frame_top.grid_rowconfigure(0, weight=1)

myframe=Frame(root, myFrame_size, relief=GROOVE, bd=1)
myframe.grid(column = 0, row = 1, sticky=N+S+E+W)

root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=100)
root.grid_columnconfigure(0, weight=5)
root.grid_columnconfigure(1, weight=1)

canvas=Canvas(myframe)
frame=Frame(canvas)
vertScrollbar=Scrollbar(myframe,orient="vertical",command=canvas.yview)
horScrollbar=Scrollbar(myframe, orient="horizontal", command=canvas.xview)
canvas.configure(yscrollcommand=vertScrollbar.set)
canvas.configure(xscrollcommand=horScrollbar.set)
canvas.grid(row=0, column=0, sticky=N+S+E+W)
myframe.grid_rowconfigure(0, weight=1)
myframe.grid_columnconfigure(0, weight=1)
vertScrollbar.grid(row=0, column=1, sticky=N+S+E)
horScrollbar.grid(row=1, sticky=S+W+E)
myframe.grid_rowconfigure(0, weight=1)
myframe.grid_columnconfigure(0, weight=100)
myframe.grid_columnconfigure(1, weight=1)
canvas_frame = canvas.create_window((0,0),window=frame, anchor = 'nw')

def myfunction(event):
    """
    Функция для обработки события фрейма(добавление скроллбара)
    Формальные переменные: -
    Возвращает: -
    Автор: Ракина А.С. БИВ174
    """
    canvas.configure(scrollregion=canvas.bbox("all"),width=600,height=event.height)

def myfunction_right(event):
    """0
    Функция для обработки события фрейма(добавление скроллбара) на правую панель
    Формальные переменные: -
    Возвращает: -
    Автор: Поздняков Филипп БИВ174
    """
    canvas_right.configure(scrollregion=canvas_right.bbox("all"),width=250,height=event.height)

def frameSize(event):
    canvas_width = event.width
    canvas_height = event.height
    canvas.itemconfig(canvas_frame, width=canvas_width, height=canvas_height)

frame.bind("<Configure>",myfunction)
frame_right.bind("<Configure>",myfunction_right)

base = import_lib(path_to_lib)
show_base(base)
lis = {}
lis['genre'] = filter_name('genre', "G E N R E:")
lis['pages'] = filter_num('pages', "P A G E S:", 50, 1000, 10)
lis['price'] = filter_num('price', "P R I C E", 50, 1000, 50)
lis['year'] = filter_num('year', "Y E A R:", 1990, 2018, 1)
filter_but.grid(row = m+1)
frame_right.grid_rowconfigure(m+1, weight=1)

root.minsize(width=450, height=300)
root.maxsize(width=950, height=700)

root.mainloop()
