path_to_lib = "../Data/books"
path_to_report = "../Output/"

color_1 = "#618685"#aaaaaa"
color_2 = "#544343" #"black"
color_3 = "#EFD0CA"#F6E7D9" #f7f6f0"
color_4 = "#ffffff"
color_5 = "#8c8c8c"
color_6 = "#ffef96" #f8d7d3"
color_7 = "#4b4b4b"
color_8 = "#f1f1f1"
color_9 = "#bfbfbf"
color_10 = "#F7AF9D" #"f18973"


font_1 = "Arial 10"
font_2 = "Arial 14"
font_3 = "Arial 18"
font_4 = "Arial 12"
font_5 = "Arial 16"

main_window_size = dict(zip(('height', 'width'), (600, 800)))#1000
frame_top_size = dict(zip(('height', 'width'), (100, 800)))#700
frame_right_size = dict(zip(('height', 'width'), (550, 300)))
button_size = dict(zip(('height', 'width'), (2, 13)))
myFrame_size = dict(zip(('height', 'width'), (500, 500)))# 700 700
frame_size = dict(zip(('height', 'width'), (500, 500))) # 550 700
record_label_size = dict(zip(('height', 'width'), (2, 10)))
but_edit_win_size = dict(zip(('height', 'width'), (2, 10)))
