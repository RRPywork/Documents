"""
Этот скрипт содержит набор функций для визуализации работы с базой данных.\n
Большинство функций скрипта внутренние и не желательны к вызову по отдельности.\n
Все функции разделены на блоки, описывающие поведение какого-либо окна (разделены комментарием рода #----Название окна----#)\n
Желательно вызывать те функции, в названии которых в конце есть W (window). Например - FindPathW или DataBaseW\n
Если появится надобность в использовании части функций приложения, следует скопировать ВЕСЬ блок, заключенный в комментарии рода #----Название окна----#,\n
а также функции ShowMainWindow и HideMainWindow.\n
Авторы: Бычков В.К., Павлов В.А., Хромов Г.А.
"""

import tkinter as tk
from tkinter import filedialog
import dataBase as db

workDir = "D:\\Work\\"

#Стили для кнопок, лейблов и т.д.
frameStyle = {"bg":"#FFEEAD","bd":10,"relief":"groove"}
buttonStyle = {"bg":"#FF6F69","fg":"#000000", "font" : ("Arial",10, "bold"), "relief" : "ridge", "bd" : 5}
labelStyle = {"bg":"#96CEB4","fg":"#000000", "font" : ("Arial",10, "bold"), "relief" : "ridge", "bd" : 5}
entryStyle = {"bg":"#FFCC5C","fg":"#000000", "font" : ("Arial",10, "bold"), "relief" : "ridge", "bd" : 5}

canvasStyle = {"bg":frameStyle["bg"]}

def parseUI():
    """
    Функция для загрузи настроек из файла setting.ini в папке Data\n
    Автор: В.А. Павлов
    """
    global frameStyle
    global buttonStyle
    global labelStyle
    global entryStyle
    global canvasStyle
   
    try:
        f = open(workDir+"Data\\settings.ini","r")
    except:
        tk.Label(None, text = "Не найден файл settings.ini", font = ("Arial",30, "bold")).pack()
        return
   #Парсинг данных из файла - eval преобразует выражение string из файла в словарь
    for i in f:
        j = i.split(sep=" = ")
        if j[0]=="frameStyle":
            frameStyle = eval(j[1])
        elif j[0] =="buttonStyle":
            buttonStyle = eval(j[1])
        elif j[0] =="labelStyle":
            labelStyle = eval(j[1])
        elif j[0] =="entryStyle":
            entryStyle = eval(j[1])
            
    canvasStyle = {"bg":frameStyle["bg"]}
    f.close()

def ShowMainWindow(mainWindow,other):
    """
    Удаляет текущее окно (other) и восстанавливает основное окно (mainWindow)\n
    \tПараметры: \n
    \t\tmainWindow - основное окно\n
    \t\tother - текущее окно (дочернее от mainWindow через Toplevel())\n
    Автор: Хромов Г.А.
    """
    mainWindow.deiconify() 
    other.destroy()

def HideMainWindow(mainWindow):
    """
    Скрывает текущее окно (mainWindow), но не удаляет его\n
    \tПараметры: \n
    \t\tmainWindow - текущее окно\n
    Автор: Хромов Г.А.
    """
    mainWindow.withdraw()

#--------------------------------------Find File window------------------------------------#
"""
Следующие функции описывают функционал окна выбора базы данных\n
Автор: Хромов Г.А.
"""
#директория для бд по умолчанию
dataDir = workDir+"Data\\Data.pic"

def FindFile(entry,dataBase):
    """
    Загружает dataBase в оперативную память (функция ReadBase в dataBase.py) по пути, написанном в поле entry\n
    \tПараметры: \n
    \t\tentry - поле типа Entry, где написан путь к файлу с базой данных\n
    \t\tdataBase - база данных (словарь словарей)\n
    Автор: Хромов Г.А.
    """
    global dataDir
    dataDir = entry.get()
    db.ReadBase(dataBase,dataDir)
    
def BrowseFile(entry,dataBase,pathW):
    """
    Загружает dataBase в оперативную память (функция ReadBase в dataBase.py) по пути, выбранном с помощью функции filedialog.Open()\n
    \tПараметры: \n
    \t\tentry - поле типа Entry, куда будет записан путь к файлу с базой данных\n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\tpathW - окно, в котором откроется filedialog.Open()\n
    Автор: Хромов Г.А.
    """
    global dataDir
    dataDir = filedialog.Open(initialdir=dataDir, filetypes=[("*.pic files", ".pic")]).show()
    db.ReadBase(dataBase,dataDir)
    entry.delete(0,"end")
    entry.insert(0,dataDir)
    
    
def FindPathW(mainWindow,dataBase):
    """
    Открывает окно выбора базы данных\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    \t\tdataBase - база данных (словарь словарей)\n
    Автор: Хромов Г.А.
    """
    pathW = tk.Toplevel(mainWindow)
    
    HideMainWindow(mainWindow)
    
    frame = tk.Frame(pathW, frameStyle)
    frame.pack(fill=tk.BOTH,expand=tk.YES)
    
    pathW.title("База данных сериалов - выбор базы данных")
    pathW.geometry("530x250+300+250")
    pathW.minsize(475,170)
    pathW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    pathW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(mainWindow,pathW))

    text = tk.Label(frame,labelStyle,text="Введите полный путь к файлу:", width=30)
    entry = tk.Entry(frame, entryStyle,width=30)
    entry.insert(0,workDir+"Data\\Data.pic")
    
    text2 = tk.Label(frame,labelStyle,text="Или выберите его через проводник:", width=30)
    browseB = tk.Button(frame,buttonStyle,text="Выбрать", width=30, command=lambda: BrowseFile(entry,dataBase,pathW))
    
    findB = tk.Button(frame,buttonStyle,text="Загрузить", width=15, command=lambda: FindFile(entry,dataBase))
    closeB = tk.Button(frame,buttonStyle, text="Назад", width=5, command=lambda: ShowMainWindow(mainWindow,pathW))

    text.grid(row=0,column=1)
    entry.grid(row=1,column=1)
    findB.grid(row=1,column=2)

    text2.grid(row=2,column=1)
    browseB.grid(row=3,column=1)
    
    closeB.grid(row=0,column=0)
 
#--------------------------------------Find Base window------------------------------------#
"""
Следующие функции описывают функционал окна поиска в базе данных\n
Автор: Павлов В.А.
"""
#tmp - текущие выбранные параметры из OptionMenu
tmp = "По названию"
tmpParam = "=="
#tkvar - наборы параметров для OptionMenu (drop-down меню)
tkvar = None #tk.StringVar()
tkvarParam = None #tk.StringVar()
#словарь, содержащий выборку из основной бд
searchResult = {}

def change_dropdown(*args):
    """
    Внутрення функция (описание ивента dropdown селектора (функция OptionMenu()))\n
    Записывает в tmp выбор из tkVar типа StringVar\n
    \tПараметры: \n
    \t\targs - аргументы функции\n
    Автор: Павлов В.А.
    """
    global tmp, tkvar
    tmp = tkvar.get()    
    
def change_dropdown_param(*args):
    """
    Внутрення функция (описание ивента dropdown селектора (функция OptionMenu()))\n
    Записывает в tmpParam выбор из tkVarParam типа StringVar\n
    \tПараметры: \n
    \t\targs - аргументы функции\n
    Автор: Павлов В.А.
    """
    global tmpParam, tkvarParam
    tmpParam = tkvarParam.get() 
    
def searchCall(dataBase,entry):
    """
    Выполняет поиск в базе данных по значению в entry\n
    \tПараметры: \n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\tentry - поле типа Entry, гдле записаное значение, по которму будет идти поиск\n
    Автор: Павлов В.А.
    """
    global searchResult
    if(tmp == "По названию"):
        searchResult = db.SearchName(dataBase, entry.get())
    elif(tmp == "По году"):
        searchResult = db.SearchYear(dataBase, entry.get(), param=tmpParam)
    elif(tmp == "По жанрам"):
        searchResult = db.SearchGenre(dataBase, entry.get())
    elif(tmp == "По актерам"):
        searchResult = db.SearchGenre(dataBase, entry.get())
    elif(tmp == "По стране"):
        searchResult = db.SearchCountry(dataBase, entry.get())
    elif(tmp == "По рейтингу"):
        searchResult = db.SearchRating(dataBase, entry.get(), param=tmpParam)
    elif(tmp =="По возрастным ограничениям"):
        searchResult = db.SearchPG(dataBase, entry.get(), param=tmpParam)
            
    
  
def FindBaseW(mainWindow,MainDataBase,dataBase,rootWindow):
    """
    Открывает окно поиска по базе данных\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    \t\tMainDataBase - изначальная база данных (словарь словарей)\n
    \t\tdataBase - база данных (словарь словарей), по которой будет проводится выборка\n
    \t\trootWindow - первое окно приложения\n
    Автор: Павлов В.А.
    """
    mainWindow.destroy()
    
    findW = tk.Toplevel(rootWindow)
    
    findW.title("База данных сериалов - поиск в базе данных")
    findW.geometry("500x250+300+250")
    findW.minsize(500,100)
    findW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    findW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(rootWindow,findW))
    
    frame = tk.Frame(findW,frameStyle)
    frame.pack(fill=tk.BOTH,expand=tk.YES)
    #choices - наборы параметров для drop-down окна
    choices = ("По названию", "По году", "По жанрам", "По актерам", "По стране", "По рейтингу", "По возрастным ограничениям")
    choicesParam = ("==",">",">=","<","<=")
    global tkvar,tkvarParam
    tkvar = tk.StringVar(frame)
    tkvar.set(choices[0])
    tkvarParam = tk.StringVar(frame)
    tkvarParam.set(choicesParam[0])
    
    selector = tk.OptionMenu(frame, tkvar, *choices)
    selector.config(buttonStyle)
    selector["menu"].config(buttonStyle) #Назначение стиля для выпадающего меню на нажатие кнопки выбора параметра
            
    selectorParam = tk.OptionMenu(frame, tkvarParam, *choicesParam)
    selectorParam.config(buttonStyle)
    selectorParam["menu"].config(buttonStyle)
                 
    selector.grid(row=0,column=2)
    selectorParam.grid(row=0,column=3)

    tkvar.trace('w', change_dropdown)
    tkvarParam.trace('w',change_dropdown_param)

    entry = tk.Entry(frame, entryStyle, width = 25)
    entry.grid(row=0,column=1)
    
    closeB = tk.Button(frame,buttonStyle, text="Назад",width=5, command = lambda: ShowMainWindow(rootWindow,findW)) 
    closeB.grid(row=0,column=0)
    
    #ВНУТРЕННЯЯ ФУНКЦИЯ
    def showResBfunc():
        """
        Внутренняя функция. Не для вызова. Осуществляет два действия: выборку данных и открытие окна с показом результата выборки.\n
        Автор: Хромов Г.А.
        """
        searchCall(dataBase,entry)
        DataBaseW(findW,MainDataBase,searchResult)
        
        
    showResB = tk.Button(frame, buttonStyle, text="Показать результат поиска", width=entry['width'], command = showResBfunc)
    showResB.grid(row=1,column=1)
    
    
#--------------------------------------Show Data Base window------------------------------------#
"""
Следующие функции описывают функционал окна показа и редактирования базы данных\n
Авторы: Бычков В.К., Хромов Г.А.
"""

def DataBaseW(mainWindow,MainDataBase,dataBase): 
    """
    Открывает окно показа и редактирования по базе данных\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    \t\tMainDataBase - база данных (словарь словарей)\n
    \t\tdataBase - база данных выводимых элементов (словарь словарей)\n
    Авторы: Бычков В.К., Хромов Г.А.
    """
    #MainDataBase - основная база данных, а dataBase - бд для вывода на экран.
    #передаются две бд, т.к. в окне с выборкой может быть вызвана эта функция. Тогда, программа должна показывать бд
    #из выборки, но в случае изменений менять основную бд
    dbW = tk.Toplevel(mainWindow)
    
    HideMainWindow(mainWindow)
    
    dbW.title("База данных сериалов - показ/редактирование базы данных")
    dbW.geometry("1000x500+100+100")
    dbW.minsize(1000,250)
    dbW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    dbW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(mainWindow,dbW))
    
    #ВНУТРЕННЯЯ ФУНКЦИЯ
    def myfunction(event):
        """
        Внутрення функция. не для вызова. Привязывает scrollbar к canvas.
        Автор: Хромов Г.А.
        """
        canvas.configure(scrollregion=canvas.bbox("all"))

    #Создание внешнего фрейма. В него будут вставлены верхний фрейм с основноыми кнопками управления и canvas под верхним фреймом
    myframe = tk.Frame(dbW, frameStyle)
    myframe.pack(anchor="nw",fill=tk.BOTH,expand=tk.YES)
    #Создание верхнего фрейма
    topframe=tk.Frame(myframe,canvasStyle)
    topframe.pack(anchor="nw")
    
    tk.Button(topframe, buttonStyle, text="Назад", command = lambda: ShowMainWindow(mainWindow,dbW)).grid(row=0,column=0)
    tk.Button(topframe, buttonStyle, text = "Сохранить изменения", command = lambda: RewriteBase(MainDataBase,tkAll)).grid(row=0,column=1)
    tk.Button(topframe, buttonStyle, text = "Добавить", command = lambda: AddToBase(frame,MainDataBase,tkAll)).grid(row=0,column=2)
    tk.Button(topframe, buttonStyle, text="Поиск в базе данных", command = lambda: FindBaseW(dbW,MainDataBase,dataBase,mainWindow)).grid(row=0,column=3)
    tk.Button(topframe, buttonStyle, text="Сохранить выборку", command = lambda: RewriteBaseFully(MainDataBase,tkAll)).grid(row=0,column=4)
    
    #Создание canvas
    canvas = tk.Canvas(myframe,canvasStyle,bd=0)
    frame = tk.Frame(canvas,canvasStyle)
    #Создание скроллбара, настроенного на прокрутку canvas
    myscrollbar = tk.Scrollbar(myframe,orient="vertical",command=canvas.yview)
    canvas.configure(yscrollcommand=myscrollbar.set)
    myscrollbar.pack(side="right",fill="y")
    canvas.pack(side="bottom",expand=tk.YES, fill=tk.BOTH)
    #Рисование еще одного фрейма на canvas. В этом фрейме будут располагаться элементы 
    canvas.create_window((0,0),window=frame,anchor="nw")
    frame.bind("<Configure>",myfunction)
    
    #Заполнение frame, содержащегося в canvas
    r = 2
    
    tk.Label(frame, labelStyle, text = "№", width=3).grid(row=1, column=0)
    tk.Label(frame, labelStyle, text = "Название", width=20).grid(row=1, column=1)
    tk.Label(frame, labelStyle, text = "Год", width=5).grid(row=1, column=2)
    tk.Label(frame, labelStyle, text = "Жанр", width=18).grid(row=1, column=3)
    tk.Label(frame, labelStyle, text = "В ролях", width=18).grid(row=1, column=4)
    tk.Label(frame, labelStyle, text = "Страна", width=18).grid(row=1, column=5)
    tk.Label(frame, labelStyle, text = "Польз. р-г", width=10).grid(row=1, column=6)
    tk.Label(frame, labelStyle, text = "Возр. р-г", width=10).grid(row=1, column=7)
    #tkAll - двумерный список всех объектов tkinter (Label, Entry, Checkbox)
    #tkArray - строка в tkAll, описывает один элемент базы данных
    #Нужен для изменения и сохраения бд
    tkAll = []
    for c in dataBase:
        tkArray =[]
        i=1
        for e in dataBase[c]:
            if e == "Индекс":
                m = tk.Label(frame, labelStyle, text = str(dataBase[c]["Индекс"]+1), width=3)
                m.grid(row=r, column=0)
                tkArray.append(m)
            else:
                if e == "Пользовательский рейтинг" or e == "Возрастной рейтинг":
                    m = tk.Entry(frame, entryStyle, width=10)    
                elif e == "Год":
                    m = tk.Entry(frame, entryStyle, width=5)
                else:
                    m = tk.Entry(frame, entryStyle, width=20)
                s = str(dataBase[c][e])
                if e == "Жанр" or e == "В ролях":
                    s = ", ".join(dataBase[c][e])    
                m.insert(0,s)
                m.grid(row=r, column=i)
                tkArray.append(m)
            i+=1
        flag = tk.IntVar()
        cb = tk.Checkbutton(frame, buttonStyle,width=2, variable=flag)
        cb.grid(row=r,column=i)
        cb.select()
        tkArray.append(flag)
        r+=1
        tkAll.append(tkArray)
    
def AddToBase(window,dataBase,tkAll):
    """
    Добавляет в окно показа и редактирования по базе данных новое поле для новой записи\n
    \tПараметры: \n
    \t\twindow - главное окно(или фрейм), в которое будет добалено поле для новго элемента\n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\ttkAll - список из tkArray (список Entry полей, Label с индексом и Checkbutton)\n
    Автор: Бычков В.К.
    """
    #Данные сериала, добавляемого по умолчанию
    data = { "Название":"","Год":0,"Жанр":[],"В ролях":[],"Страна":"","Пользовательский рейтинг":0.0,"Возрастной рейтинг":0,"Индекс":len(dataBase)}
    i=1
    tkArray=[]
    #Создание объектов tkinter для нового элемента бд и занесение их в tkAll
    for e in data:
            if e == "Индекс":
                m = tk.Label(window, labelStyle, text = str(len(dataBase) + 1), width=3)
                m.grid(row=len(dataBase) + 2, column=0)
                tkArray.append(m)
            else:
                if e == "Название":
                    m = tk.Entry(window, entryStyle, width=20)
                    m.insert(0," ")
                elif e == "Год":
                    m = tk.Entry(window, entryStyle, width=5)
                    m.insert(0,"0")
                elif e == "Жанр":
                    m = tk.Entry(window, entryStyle, width=20)
                    m.insert(0," ")
                elif e == "В ролях":
                    m = tk.Entry(window, entryStyle, width=20)
                    m.insert(0," ")
                elif e == "Страна":
                    m = tk.Entry(window, entryStyle, width=20)
                    m.insert(0," ")
                elif e == "Пользовательский рейтинг":
                    m = tk.Entry(window, entryStyle, width=10)
                    m.insert(0,"0.0")
                elif e == "Возрастной рейтинг":
                    m = tk.Entry(window, entryStyle, width=10)
                    m.insert(0,"0")
                m.grid(row=len(dataBase) + 2, column=i)
                tkArray.append(m)
                i+=1
    flag = tk.IntVar()
    cb = tk.Checkbutton(window, buttonStyle, width=2, variable=flag)
    cb.grid(row=len(dataBase) + 2,column=i+1)
    cb.select()
    tkArray.append(flag)
    tkAll.append(tkArray)
    dataBase[len(dataBase)] = data
    
def RewriteBase(dataBase,tkAll):
    """
    Сохраняет в оперативную память базу данных, отредактированную в Entry Полях tkArray\n
    \tПараметры: \n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\ttkArray - список из tkRow (список Entry полей, Label с индексом и Checkbutton)\n
    Автор: Бычков В.К.
    """
    i=0
    TD = { 
        "Название":"",
        "Год":0,
        "Жанр":[],
        "В ролях":[],
        "Страна":"",
        "Пользовательский рейтинг":0.0,
        "Возрастной рейтинг":0,
        "Индекс":0
         }
    #Цикл пробегает по строке в tkAll и формирует элемент TD (один элемент в основной бд) из данных в tkinter-объектах из tkAll
    #Далее элемент или удаляется из основной бд через индекс (если галочка удаления была снята), или перезаписывает текущий элемент бд
    for tkArray in tkAll:
        for tkElement in tkArray:
            if i!=7:
                z = tkElement.get()
                if i==0:
                    TD["Название"] = z
                elif i==1:
                    TD["Год"] = int(z)
                elif i==2:
                    z = z.split(", ")
                    TD["Жанр"] = z
                elif i==3:
                    z = z.split(", ")
                    TD["В ролях"] = z
                elif i==4:
                    TD["Страна"] = z
                elif i==5:
                    TD["Пользовательский рейтинг"] = float(z)
                elif i==6:
                    TD["Возрастной рейтинг"] = int(z)
            elif i==7:
                TD["Индекс"] = int(tkElement["text"])-1
            
            i+=1
        if tkArray[8].get() == 1:
            dataBase[TD["Индекс"]] = TD.copy()
        else:
            del dataBase[TD["Индекс"]]
        i=0
        
    db.ReIndexate(dataBase)

def RewriteBaseFully(dataBase,tkAll):
    """
    Сохраняет в оперативную память выборку из основной базы данных\n
    \tПараметры: \n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\ttkArray - список из tkRow (список Entry полей, Label с индексом и Checkbutton)\n
    Автор: Хромов Г.А.
    """
    i=0
    TD = { 
        "Название":"",
        "Год":0,
        "Жанр":[],
        "В ролях":[],
        "Страна":"",
        "Пользовательский рейтинг":0.0,
        "Возрастной рейтинг":0,
        "Индекс":0
         }
    #Цикл пробегает по строке в tkAll и формирует элемент TD (один элемент в основной бд) из данных в tkinter-объектах из tkAll
    #Далее элемент или удаляется из основной бд через индекс (если галочка удаления была снята), или перезаписывает текущий элемент бд
    for c in dataBase:
        dataBase[c].clear()
    dataBase.clear()
    
    k=0
    for tkArray in tkAll:
        for tkElement in tkArray:
            if i!=7:
                z = tkElement.get()
                if i==0:
                    TD["Название"] = z
                elif i==1:
                    TD["Год"] = int(z)
                elif i==2:
                    z = z.split(", ")
                    TD["Жанр"] = z
                elif i==3:
                    z = z.split(", ")
                    TD["В ролях"] = z
                elif i==4:
                    TD["Страна"] = z
                elif i==5:
                    TD["Пользовательский рейтинг"] = float(z)
                elif i==6:
                    TD["Возрастной рейтинг"] = int(z)
            elif i==7:
                TD["Индекс"] = int(tkElement["text"])-1
            
            i+=1
        dataBase[k]=TD.copy()
        i=0
        k+=1
        
    db.ReIndexate(dataBase)


#--------------------------------------About app window------------------------------------#
"""
Следующие функции описывают функционал окна \"О программе\"\n
Автор: Хромов Г.А.
"""   
def AboutW(mainWindow):
    """
    Открывает окно \"О программе\"\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    Автор: Хромов Г.А.
    """
    aboutW = tk.Toplevel(mainWindow)
    
    HideMainWindow(mainWindow)
    
    aboutW.title("База данных сериалов - о приложении")
    aboutW.geometry("500x250+300+250")
    aboutW.minsize(280,160)
    aboutW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    aboutW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(mainWindow,aboutW))
    
    frame = tk.Frame(aboutW,frameStyle)
    frame.pack(fill=tk.BOTH,expand=tk.YES)
    
    tk.Label(frame, labelStyle, text="О приложении:").grid(row=0,column=1,columnspan=2)
    tk.Label(frame, labelStyle, text="Разработчики:").grid(row=1,column=0)
    tk.Label(frame, labelStyle, text="Хромов Г.А.").grid(row=1,column=1)
    tk.Label(frame, labelStyle, text="Бычков В.К.").grid(row=2,column=1)
    tk.Label(frame, labelStyle, text="Павлов В.А.").grid(row=3,column=1)
    tk.Button(frame, buttonStyle, text="Назад", command = lambda: ShowMainWindow(mainWindow,aboutW)).grid(row=0,column=0)

#--------------------------------------Stats window------------------------------------#
"""
Следующие функции описывают функционал окна подведения итогов (статистика)\n
Автор: Хромов Г.А.
"""   
def StatsW(mainWindow, dataBase):
    """
    Открывает окно подведения итогов (статистика)\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    \t\tdataBase - база данных (словарь словарей)\n
    Автор: Хромов Г.А.
    """
    statsW = tk.Toplevel(mainWindow)
    
    HideMainWindow(mainWindow)
    
    statsW.title("База данных сериалов - подведение итога (статистика)")
    statsW.geometry("520x250+300+250")
    statsW.minsize(520,230)
    statsW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    statsW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(mainWindow,statsW))
    
    frame = tk.Frame(statsW,frameStyle)
    frame.pack(fill=tk.BOTH,expand=tk.YES)
    
    tk.Label(frame,labelStyle, text="Итог записан в файл log.txt в папке Output. Содержимое файла:").grid(row=0,column=1)
    #вызов функции, формирующей статистику в log.txt
    db.CookStats(dataBase)
    
    #Чтение файла и формирование строки для вывода на экран
    f = open(workDir+"Output\\log.txt","r")
    s = str()
    for line in f:
        s += line
    f.close()
    tk.Label(frame,labelStyle, text=s).grid(row=1,column=1)
    
    tk.Button(frame, buttonStyle, text="Назад", command = lambda: ShowMainWindow(mainWindow,statsW)).grid(row=0,column=0)
   
#--------------------------------------Save base window------------------------------------#
"""
Следующие функции описывают функционал окна выбора базы данных\n
Автор: Хромов Г.А.
"""
#директория для файла с сохраненной бд   
saveDir = workDir+"Data\\DataNew.pic"

def SaveFile(entry,dataBase):
    """
    Сохраняет dataBase в файл (функция SaveBase в dataBase.py) по пути, написанном в поле entry\n
    \tПараметры: \n
    \t\tentry - поле типа Entry, где написан путь к файлу, где будет сохранена база данных\n
    \t\tdataBase - база данных (словарь словарей)\n
    Автор: Хромов Г.А.
    """
    global saveDir
    saveDir = entry.get()
    db.SaveBase(dataBase,saveDir)
    
def BrowseAndSaveFile(entry,dataBase,sbW):
    """
    Сохраняет dataBase в файл (функция SaveBase в dataBase.py) по пути, выбранном с помощью функции filedialog.asksaveasfilename()\n
    \tПараметры: \n
    \t\tentry - поле типа Entry, куда будет записан путь к файлу с базой данных\n
    \t\tdataBase - база данных (словарь словарей)\n
    \t\tsbW - окно, в котором откроется filedialog.asksaveasfilename()\n
    Автор: Хромов Г.А.
    """
    global saveDir
    saveDir = filedialog.asksaveasfilename(initialdir=saveDir, filetypes=[("*.txt files", ".txt")])
    db.SaveBase(dataBase,saveDir)
    entry.delete(0,"end")
    entry.insert(0,saveDir)
    
def SaveBaseW(mainWindow,dataBase):
    """
    Открывает окно сохранения базы данных\n
    \tПараметры: \n
    \t\tmainWindow - главное окно, которое будет скрыто и на основании которого будет создано это дочернее окно (функция Toplevel())\n
    \t\tdataBase - база данных (словарь словарей)\n
    Автор: Хромов Г.А.
    """
    sbW = tk.Toplevel(mainWindow)
    
    HideMainWindow(mainWindow)
    
    sbW.title("База данных сериалов - сохранение базы данных")
    sbW.geometry("500x250+300+250")
    sbW.minsize(475,170)
    sbW.iconbitmap(workDir+"Graphics\\icon.ico")
    #Переназначение кнопки закрыть: функция аналогична нажатию на кнопку "Назад"
    sbW.protocol("WM_DELETE_WINDOW",lambda: ShowMainWindow(mainWindow,sbW))
    
    frame = tk.Frame(sbW,frameStyle)
    frame.pack(fill=tk.BOTH,expand=tk.YES)

    text = tk.Label(frame, labelStyle, text="Введите полный путь к файлу:", width=30)
    entry = tk.Entry(frame, entryStyle, width=30)
    entry.insert(0,saveDir)
    
    text2 = tk.Label(frame, labelStyle, text="Или выберите его через проводник:", width=30)
    browseB = tk.Button(frame, buttonStyle, text="Выбрать", width=30, command=lambda: BrowseAndSaveFile(entry,dataBase,sbW))
    
    findB = tk.Button(frame, buttonStyle, text="Сохранить файл", width=15, command=lambda: SaveFile(entry,dataBase))
    closeB = tk.Button(frame, buttonStyle, text="Назад", width=5, command=lambda: ShowMainWindow(mainWindow,sbW))

    text.grid(row=0,column=1)
    entry.grid(row=1,column=1)
    findB.grid(row=1,column=2)

    text2.grid(row=2,column=1)
    browseB.grid(row=3,column=1)
    
    closeB.grid(row=0,column=0)
