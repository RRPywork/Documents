"""
Этот скрипт содержит набор функций для работы с базой данных\n
Авторы: Бычков В.К., Павлов В.А., Хромов Г.А.
"""

workDir = "D:\\Work\\"

import pickle as pk

def ReadBase(dataBase, fName):
    """
    Считывает базу данных из файла fName и записывает в оперативную память базу данных в виде словаря словарей\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tfName - имя файла с базой данных\n
    Автор: Бычков В.К.
    """
    try: 
        f = open(fName,"rb")
    except:
        return
    data = pk.load(f)
    dataBase.clear()
    x = 0
    for key in data:
        dataBase[x] = data[key].copy()
        x += 1
    
    f.close()
    
def SearchName(dataBase, value):
    """
    Ищет в базе данных сериалы с названием value. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - имя сериала, по которому будет производится поиск\n
    Автор: Павлов В.А.
    """
    result = {}
    i=0
    for base in dataBase:
        if value in dataBase[base]["Название"]:
            result[i] = dataBase[base]
            i+=1
    return result

def SearchYear(dataBase, value, param):
    """
    Ищет в базе данных сериалы с годом value. Поиск осуществляется по условию param. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - год выпуска, по которому будет производится поиск сериалов,\n
    \t\tparam - параметр поиска ("==" ИЛИ ">" ИЛИ ">=" ИЛИ "<" ИЛИ "<=")
    Автор: Хромов Г.А.
    """
    try:
        value = int(value)
    except:
        return None
    result = {}
    i=0
    if(param=="=="):
        for base in dataBase:
            if (value == int(dataBase[base]["Год"])):
                result[i]=dataBase[base]
                i+=1
    elif(param==">"):
        for base in dataBase:
            if (int(dataBase[base]["Год"]) > value):
                result[i]=dataBase[base]
                i+=1
    elif(param=="<"):
        for base in dataBase:
            if (int(dataBase[base]["Год"]) < value):
                result[i]=dataBase[base]
                i+=1
    elif(param=="<="):
        for base in dataBase:
            if (int(dataBase[base]["Год"]) <= value):
                result[i]=dataBase[base]
                i+=1
    elif(param==">="):
        for base in dataBase:
            if (int(dataBase[base]["Год"]) >= value):
                result[i]=dataBase[base]
                i+=1
    return result

def SearchGenre(dataBase, value):
    """
    Ищет в базе данных сериалы с жанром value. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - название жанра, по которому будет производится поиск сериалов\n
    Автор: Бычков В.К.
    """
    result = {}
    i = 0
    for base in dataBase:
        for baseGenre in dataBase[base]["Жанр"]:
            if value in baseGenre:
                result[i] = dataBase[base]
                i+=1
    return result

def SearchCast(dataBase, value):
    """
    Ищет в базе данных сериалы, где играет актер value. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - имя актера, по которому будет производится поиск сериалов\n
    Автор: Хромов Г.А.
    """
    result = {}
    i = 0
    for base in dataBase:
        for baseCast in dataBase[base]["В ролях"]:
            if value in baseCast:
                result[i] = dataBase[base]
                i+=1
    return result

def SearchCountry(dataBase, value):
    """
    Ищет в базе данных сериалы, произведенные в стране value. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - страна, по которой будет производится поиск сериалов\n
    Автор: Бычков В.К.
    """
    result = {}
    i = 0
    for base in dataBase:
        if value in dataBase[base]["Страна"]:
            result[i] = dataBase[base]
            i+=1
    return result

def SearchRating(dataBase, value, param):
    """
    Ищет в базе данных сериалы с пользовательским рейтингом value. Поиск осуществляется по условию param. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - пользовательский рейтинг, по которому будет производится поиск сериалов,\n
    \t\tparam - параметр поиска ("==" ИЛИ ">" ИЛИ ">=" ИЛИ "<" ИЛИ "<=")
    Автор: Павлов В.А.
    """
    try:
        value = float(value)
    except:
        return None
    result = {}
    i = 0
    if(param=="=="):
        for base in dataBase:
            if (value == float(dataBase[base]["Пользовательский рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param==">"):
        for base in dataBase:
            if (value < float(dataBase[base]["Пользовательский рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param=="<"):
        for base in dataBase:
            if (value > float(dataBase[base]["Пользовательский рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param=="<="):
        for base in dataBase:
            if (value >= float(dataBase[base]["Пользовательский рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param==">="):
        for base in dataBase:
            if (value <= float(dataBase[base]["Пользовательский рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    return result

def SearchPG(dataBase, value, param):
    """
    Ищет в базе данных сериалы с возрастным рейтингом value. Поиск осуществляется по условию param. Результатом является словарь словарей найденных сериалов. В случае неудачи возвращает пустой словарь\n
    \tПараметры: \n
    \t\tdataBase - база данных, \n
    \t\tvalue - возрастной рейтинг, по которому будет производится поиск сериалов,\n
    \t\tparam - параметр поиска ("==" ИЛИ ">" ИЛИ ">=" ИЛИ "<" ИЛИ "<=")
    Автор: Хромов Г.А.
    """
    try:
        value = int(value)
    except:
        return None
    result = {}
    i = 0
    if(param=="=="):
        for base in dataBase:
            if (value == int(dataBase[base]["Возрастной рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param==">"):
        for base in dataBase:
            if (value < int(dataBase[base]["Возрастной рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param=="<"):
        for base in dataBase:
            if (value > int(dataBase[base]["Возрастной рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param=="<="):
        for base in dataBase:
            if (value >= int(dataBase[base]["Возрастной рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    elif(param==">="):
        for base in dataBase:
            if (value <= int(dataBase[base]["Возрастной рейтинг"])):
                result[i] = dataBase[base]
                i+=1
    return result
    
def DelBaseElement(dataBase, name):
    """
    Удаляет конкретный сериал из базы данных dataBase по названию name\n
    \tПараметры:\n
    \t\tdataBase - база данных,\n
    \t\tname - название сериала\n
    Автор: Хромов Г.А.
    """
    for base in dataBase:
        if dataBase[base]["Название"] == name:
            dataBase.pop(base)
            return
    return None

def ReIndexate(dataBase):
    """
    Выполняет переиндексацию словарей в базе данных dataBase\n
    \tПараметры:\n
    \t\tdataBase - база данных\n
    Автор: Хромов Г.А.
    """
    i = 0
    tempBase = {}
    for base in dataBase:
        tempBase[i] = dataBase[base].copy()
        tempBase[i]["Индекс"] = i
        i+=1
    dataBase.clear()
    for i in range(0,len(tempBase)):
        dataBase[i] = tempBase[i].copy()

def AddBaseElement(dataBase, name, year, cast, genre, country, rating, PG):
    """
    Добавляет конкретный сериал из базы данных dataBase c названием name, годом year, списком актеров cast, списком жанров genre, страной производства country, пользовательским рейтингом rating и возрастным рейтингом PG\n
    \tПараметры:\n
    \t\tdataBase - база данных,\n
    \t\tname - название сериала,\n
    \t\tyear - год выпуска сериала,\n
    \t\tcast - список актеров сериала,\n
    \t\tgenre - список жанров сериала,\n
    \t\tcountry - страна производства сериала,\n
    \t\trating - пользовательский рейтинг сериала,\n
    \t\tPG - возрастной рейтинг сериала\n
    Автор: Бычков В.К.
    """
    data = { 
        "Название":name,
        "Год":int(year),
        "Жанр":list(genre),
        "В ролях":list(cast),
        "Страна":country,
        "Пользовательский рейтинг":float(rating),
        "Возрастной рейтинг":int(PG)
         }
    dataBase[len(dataBase)] = data

def ChangeBaseElement(dataBase, index, newName, newYear, newGenre, newCast, newCountry, newRating, newPG):
    """
    Изменяет конкретный сериал из базы данных dataBase c индексом index. newName, newYear, newCast, newGenre, newCountry, newRating, newPG - новые параметры\n
    \tПараметры:\n
    \t\tdataBase - база данных,\n
    \t\tnewName - новое название сериала,\n
    \t\tnewYear - новый год выпуска сериала,\n
    \t\tnewCast - новый список актеров сериала,\n
    \t\tnewGenre - новый список жанров сериала,\n
    \t\tnewCountry - новая страна производства сериала,\n
    \t\tnewRating - новый пользовательский рейтинг сериала,\n
    \t\tnewPG - новый возрастной рейтинг сериала\n
    Автор: Бычков В.К.
    """
    dataBase[int(index)]={
        "Название":newName,
        "Год":int(newYear),
        "Жанр":list(newGenre),
        "В ролях":list(newCast),
        "Страна":newCountry,
        "Пользовательский рейтинг":float(newRating),
        "Возрастной рейтинг":int(newPG),
        "Индекс":int(index)
        }
        
def CookStats(dataBase):
    """
    Записывает статистику по базе данных dataBase в файл log.txt в папке Output.\n
    Статистика включает в себя количество записей в dataBase, средний пользовательский рейтинг и его дисперсию, средний возрастной рейтинг и его дисперсию\n
    \tПараметры:\n
    \t\tdataBase - база данных\n
    Автор: Хромов Г.А.
    """
    if dataBase == {}:
        log = open(workDir+"Output\\log.txt","w")
        print("База данных пуста",file=log)
        log.close()   
        return
    count = 0
    meanRating = 0
    meanPG = 0
    for data in dataBase:
        meanRating+=dataBase[data]["Пользовательский рейтинг"]
        meanPG+=dataBase[data]["Возрастной рейтинг"]
        count+=1
    meanRating = float(meanRating/count)
    meanPG = float(meanPG/count)
    
    dispRating = 0
    dispPG = 0
    for data in dataBase:
        dispRating += (dataBase[data]["Пользовательский рейтинг"] - meanRating)**2
        dispPG += (dataBase[data]["Возрастной рейтинг"] - meanPG)**2
        
    dispRating = float(dispRating/count)
    dispPG = float(dispPG/count)
    
    log = open(workDir+"Output\\log.txt","w")
    
    print("Количество записей:",count,file=log)
    print("Средний пользовательский рейтинг:",meanRating,file=log)
    print("Дисперсия пользовательского рейтинга:",dispRating,file=log)
    print("Средний возрастной рейтинг:",meanPG,file=log)
    print("Дисперсия возрастного рейтинга:",dispPG,file=log)
    
    log.close()    

def SaveBase(dataBase,f):
    """
    Сохраняет dataBase в файл f\n
    \tПараметры:\n
    \t\tdataBase - база данных\n
    \t\tf - название файла\n
    Автор: Бычков В.К.
    """
    try:
        SaveFile = open(f,"wb")
    except:
        return
    
    pk.dump(dataBase,file = SaveFile)
    SaveFile.close()
